> 【章节重点难点总结】

- 要点：事件时间/水位线、状态快照、反压与容灾
- 难点：Exactly-Once端到端语义的可验证性

> 【课后思考/练习题】

1. 给出端到端延迟SLA的测量与告警方案。
2. 如何通过故障注入验证状态一致性？


## Hadoop生态系统自动化测试示例

> 【阅读提示】本篇聚焦：Hadoop生态系统自动化测试示例。建议先看结构，再带着问题阅读，关注关键术语、流程与案例，结合自身项目做对照。

class HadoopEcosystemTest:
    def __init__(self, config):
        self.config = config
        self.hdfs_client = self._create_hdfs_client()
        self.yarn_client = self._create_yarn_client()
        self.hive_client = self._create_hive_client()
        self.hbase_client = self._create_hbase_client()

    def _create_hdfs_client(self):
        """创建HDFS客户端"""
        from hdfs import InsecureClient
        return InsecureClient(
            f"http://{self.config['namenode_host']}:{self.config['namenode_port']}",
            user=self.config['hadoop_user']
        )

    def _create_yarn_client(self):
        """创建YARN客户端"""
        # YARN客户端创建逻辑
        pass

    def _create_hive_client(self):
        """创建Hive客户端"""
        import pyhive
        from pyhive import hive
        return hive.Connection(
            host=self.config['hive_server_host'],
            port=self.config['hive_server_port'],
            username=self.config['hive_user']
        )

    def _create_hbase_client(self):
        """创建HBase客户端"""
        # HBase客户端创建逻辑
        pass

    def test_hdfs_operations(self):
        """测试HDFS基本操作"""
        # 创建测试目录
        test_dir = f"/test_{int(time.time())}"
        self.hdfs_client.makedirs(test_dir)

        # 验证目录创建
        assert self.hdfs_client.status(test_dir, strict=False) is not None,
            "Failed to create directory in HDFS"

        # 上传测试文件
        test_content = b"This is a test file for HDFS operations"
        test_file_path = f"{test_dir}/test.txt"

        with self.hdfs_client.write(test_file_path, overwrite=True) as writer:
            writer.write(test_content)

        # 验证文件内容
        with self.hdfs_client.read(test_file_path) as reader:
            content = reader.read()
            assert content == test_content,
                "File content verification failed"

        # 删除测试目录
        self.hdfs_client.delete(test_dir, recursive=True)

        # 验证删除
        assert self.hdfs_client.status(test_dir, strict=False) is None,
            "Failed to delete directory from HDFS"

        return {"status": "passed", "message": "HDFS operations test passed"}

    def test_mapreduce_job(self):
        """测试MapReduce作业执行"""
        # 创建测试输入数据
        input_dir = f"/mapreduce_input_{int(time.time())}"
        self.hdfs_client.makedirs(input_dir)

        # 写入测试数据
        test_data = b"Hello World\nHello Hadoop\nMapReduce Test"
        with self.hdfs_client.write(f"{input_dir}/data.txt", overwrite=True) as writer:
            writer.write(test_data)

        # 输出目录
        output_dir = f"/mapreduce_output_{int(time.time())}"

        try:
            # 提交MapReduce作业（使用示例命令）
            import subprocess
            result = subprocess.run(
                [
                    "hadoop", "jar",
                    "/opt/hadoop/share/hadoop/mapreduce/hadoop-mapreduce-examples-3.3.1.jar",
                    "wordcount",
                    input_dir,
                    output_dir
                ],
                capture_output=True,
                text=True,
                timeout=300
            )

            # 检查作业是否成功
            assert result.returncode == 0,
                f"MapReduce job failed: {result.stderr}"

            # 验证输出结果
            output_files = self.hdfs_client.list(output_dir)
            assert "part-r-00000" in output_files,
                "Output file not found"

            # 读取并验证输出
            with self.hdfs_client.read(f"{output_dir}/part-r-00000") as reader:
                output = reader.read().decode('utf-8')
                assert "Hello\t2" in output,
                    "Expected word count not found"
                assert "World\t1" in output,
                    "Expected word count not found"

            return {"status": "passed", "message": "MapReduce job test passed"}
        finally:
            # 清理测试数据
            self.hdfs_client.delete(input_dir, recursive=True)
            if self.hdfs_client.status(output_dir, strict=False) is not None:
                self.hdfs_client.delete(output_dir, recursive=True)
